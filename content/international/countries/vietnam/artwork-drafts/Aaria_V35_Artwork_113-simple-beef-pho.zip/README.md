# Aaria V3.5 Vietnam artwork and implementation draft

This package contains 30 selected square PNG assets: four distinct step illustrations and one finished-dish image for each recipe #111–#116. The localized recipe drafts and exact step-to-image paths are under `content/international/countries/vietnam/`; the overview is `artwork-manifest.json`.

All six recipe bundles and assets remain drafts. Content, food safety, artwork accuracy/style, accessibility, artwork rights, nutrition and independent review gates are pending. Nutrition is intentionally blank pending sourced calculation. Previous generated hero candidates are recorded by blob ID in the manifest as unreviewed draft candidates.

The 13 earlier bundles (#097–098 and #100–110) remain in the branch with their existing pending review and artwork-rights statuses. This package covers the new #111–#116 artwork only.

Prompts used the locked textual guide `content/international/ARTWORK_STYLE_GUIDE.json`; Aaria is depicted with dark curly hair, a pink flower, white chef jacket and orange apron, with no text. The approved reference is recorded at `content/international/countries/italy/096-tomato-basil-pasta/artwork/steps/step-02.png` (SHA-256 `7cbeaf3b4d148558e07e9988a0316fdc75b57444c83cdd2977acead19a2d43ec`). The reference image itself was not supplied as a conditioning input in this generation run, so visual comparison remains a required review gate.

Equipment is localized as text chips only. Separate ingredient illustrations are not required for these bundles because ingredients appear in step and finished-dish art; bilingual metric ingredient lists are included. No cooking timers are included. Adults are explicitly assigned knives, raw meat, boiling liquids, hot pans and hot appliances.
