Aaria V3.5 draft artwork collection

This archive contains the nine artwork PNG files currently available in the workspace. They are draft images only. Their recipe mapping, style compliance, safety, rights, and independent review have not been confirmed. Do not treat them as approved production artwork.

The six earlier image blobs identified by Git object IDs are not included because their image bytes were not available in the workspace.
